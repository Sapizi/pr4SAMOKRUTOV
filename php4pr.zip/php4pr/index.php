<?php
session_start();
$db = new mysqli('151.248.115.10', 'root', 'Kwuy1mSu4Y', 'is64_Samokrutov');
if ($db->connect_error) {
    die('Ошибка подключения: ' . $db->connect_error);
}
$action = $_GET['action'] ?? 'home';
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}
if ($action === 'home') {
    if (isAuthenticated()) {
        echo "Добро пожаловать, пользователь! <a href='?action=logout'>Выйти</a><br>";
        if (isAdmin()) {
            echo "<a href='?action=admin'>Управление пользователями</a>";
        } else {
            echo "<a href='?action=account'>Редактировать аккаунт</a>";
        }
    } else {
        echo "<a href='?action=register'>Регистрация</a> | <a href='?action=login'>Вход</a>";
    }
}
if ($action === 'register') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param('sss', $username, $email, $password);

        if ($stmt->execute()) {
            echo "Регистрация успешна! <a href='?action=login'>Войти</a>";
        } else {
            if ($stmt->errno === 1062) {
                echo "Пользователь с таким email уже существует!";
            } else {
                echo "Ошибка: " . $stmt->error;
            }
        }
        $stmt->close();
    } else {
        echo '<form method="POST">
            <input name="username" placeholder="Имя" required>
            <input name="email" type="email" placeholder="Email" required>
            <input name="password" type="password" placeholder="Пароль" required>
            <button type="submit">Регистрация</button>
        </form>';
    }
}
if ($action === 'login') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $stmt = $db->prepare("SELECT id, password, role FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($user_id, $hashed_password, $role);
        $stmt->fetch();
        if ($user_id && password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['role'] = $role;
            header("Location: ?action=home");
            exit;
        } else {
            echo "Неверный email или пароль!";
        }
        $stmt->close();
    } else {
        echo '<form method="POST">
            <input name="email" type="email" placeholder="Email" required>
            <input name="password" type="password" placeholder="Пароль" required>
            <button type="submit">Войти</button>
        </form>';
    }
}
if ($action === 'logout') {
    session_destroy();
    header("Location: ?action=home");
    exit;
}
if ($action === 'account' && isAuthenticated()) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;
        $sql = "UPDATE users SET username = ?, email = ?";
        $params = [$username, $email];
        $types = "ss";
        if ($password) {
            $sql .= ", password = ?";
            $params[] = $password;
            $types .= "s";
        }
        $sql .= " WHERE id = ?";
        $params[] = $_SESSION['user_id'];
        $types .= "i";
        $stmt = $db->prepare($sql);
        $stmt->bind_param($types, ...$params);
        if ($stmt->execute()) {
            echo "Данные обновлены!";
        } else {
            echo "Ошибка: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo '<form method="POST">
            <input name="username" value="Имя" required>
            <input name="email" type="email" value="Email" required>
            <input name="password" type="password" placeholder="Новый пароль">
            <button type="submit">Сохранить</button>
        </form>';
    }
}
if ($action === 'admin' && isAdmin()) {
    $result = $db->query("SELECT username, email FROM users");
    while ($user = $result->fetch_assoc()) {
        echo "{$user['username']} - {$user['email']}<br>";
    }
    $result->free();
}
